import React from 'react';
import StyleEditor from './styleEditor';
import Heart from './heart';
import HeartRain from './heartRain';
import "./box.css"
const isPc = (function () {
  var userAgentInfo = navigator.userAgent;
  var Agents = ["Android", "iPhone",
    "SymbianOS", "Windows Phone",
    "iPad", "iPod"
  ];
  var flag = true;
  for (var v = 0; v < Agents.length; v++) {
    if (userAgentInfo.indexOf(Agents[v]) > 0) {
      flag = false;
      break;
    }
  }
  return flag;
}());

export default class App extends React.Component {

  fullStyle = [
    `/*
* Hi。宝贝！
* 这么久了。还没和宝贝说过我的工作呢！
* 我是个前端工程师。俗称程序员。网页相关。
* 如这个页面。就是个什么也没有的网页。
* 我的工作就是给这种空白的页面加点儿东西。
*/

/* 首先给我要所有元素加上过渡效果，让他们变得好看一些 */
* {
  -webkit-transition: all .5s;
  transition: all .5s;
}
/* 白色背景太单调了。送你一个粉色的背景 */
body, html {
  color: white;
  background-color: green;
}

/* 文字太近了 */
.styleEditor {
  overflow: auto;
  ${isPc ? `width: 48vw;
  height: 96vh;` : `width: 96vw;
  height: 48vh;` }
  border: 1px solid;
  font-size: 14px;
  line-height: 1.5;
  padding: 10px;
}

/* 给代码添加颜色 */
.token.selector{ color: rgb(133,153,0) }
.token.property{ color: rgb(187,137,0) }
.token.punctuation{ color: yellow }
.token.function{ color: rgb(42,161,152) }
.token.comment{ color: rgb(177,177,177) }

/*
* 宝贝，情人节快到了想要什么礼物呢。
* 送你一个小心心吧。
*/

/* 首先需要来一个画板 */
.heartWrapper {
  width: 48vw;
  height: 96vh;
  position: relative;
  border: 1px solid;
  background-color: white;
  transform: rotateY(-10deg) translateZ(-100px);
  -webkit-transform: rotateY(-10deg) translateZ(-100px);
}

/* 再画一个方块，当做左心室和右心室 */
.heart {
  width: 100px;
  height: 100px;
  position: absolute;
  top: 50%;
  left: 50%;
  margin: -50px 0 0 -50px;
  border-radius: 20px;
  background: #E88D8D;
  transform: rotate(45deg);
}

/* 画上左心房 */
.heart::before {
  content: '';
  background: #E88D8D;
  border-radius: 50%;
  width: 100px;
  height: 100px;
  position: absolute;
  left: -38px;
  top: 1px;
}

/* 再画上右心房 */
.heart::after {
  content: '';
  background: #E88D8D;
  border-radius: 50%;
  width: 100px;
  height: 100px;
  position: absolute;
  right: -1px;
  top: -38px;
}

/* 让小心心跳起来 */
@keyframes throb {
  0% {
    transform: scale(1) rotate(45deg);
    opacity: 1;
  }

  100% {
    transform: scale(1.65) rotate(45deg);
    opacity: 0
  }
}

.bounce {
  opacity: 0.2;
  animation: throb 1s infinite linear;
}
/*
* Ok，完成！
* 宝贝，七夕快乐！
*/
`
  ]

  state = {
    currentStyleCode: '',
    finished: false,
    heartRains: [],
    isNo: false,
    isOne: false,
    isTwo: false,
    isThree: false,
    one: "天空的幸福是穿一身蓝，森林的幸福是披—身绿，阳光的",
    two: "幸福是如钻石半耀眼，而我最大的幸福是和你在—起，真",
    three: "的很感谢你，我永远的爱人!"
  }

  interval = 30;
  // interval = 0;

  async progressiveShowStyle(n = 0) {
    const {
      interval,
      fullStyle
    } = this;
    const showStyle = i => new Promise((resolve) => {
      const style = fullStyle[n];
      const char = style[i];
      if (!style || !char) {
        resolve();
        return;
      }
      let {
        currentStyleCode
      } = this.state;
      currentStyleCode += char;
      this.setState({
        currentStyleCode
      });
      if (char === '\n' && this.styleEditor) {
        this.styleEditor.toBottom();
      }
      setTimeout(() => {
        resolve(showStyle(i + 1));
      }, interval);
    });
    return showStyle(0);
  }

  componentDidMount() {
    this.progressiveShowStyle(0);
    this.setState({ finished: true });
    this.rain();
    setTimeout(() => {
      this.setState({
        isNo: true,
      })
      setTimeout(() => {
        this.setState({
          isOne: true,
        })
        setTimeout(() => {
          this.setState({
            isTwo: true
          })
          setTimeout(() => {
            this.setState({
              isThree: true
            })
          }, 500)
        }, 500)
      }, 500)
    }, 63000)


  }
  saveStyleEditorRef = child => this.styleEditor = child;

  rain = () => {
    let { heartRains } = this.state;
    const rainNum = 30;
    // const stayTime = rainNum * 200 + 1000 + 4000;
    const stayTime = rainNum * 200 + 1000;
    const time = (new Date()).getTime();
    if (!heartRains.length || (time - heartRains[heartRains.length - 1].time > (stayTime / 2))) {
      heartRains.push({ time, rainNum });
      this.setState({ heartRains });
      setTimeout(() => {
        this.removeRain(time);
      }, stayTime);
    }
  }
  removeRain(time) {
    let { heartRains } = this.state;
    heartRains = heartRains.filter(item => item.time !== time);
    this.setState({ heartRains });
  }
  render() {
    const { currentStyleCode, finished, heartRains } = this.state;
    return <div id='h'>
      <div style={{ display: isPc ? 'flex' : '' }}>
        <StyleEditor ref={this.saveStyleEditorRef} code={currentStyleCode} />
        <Heart click={finished ? this.rain : null} />
      </div>
      {
        heartRains.map(item => <HeartRain num={item.rainNum} key={item.time} />)
      }
      {
        this.state.isNo ? <div className='box'>{this.state.isOne ? this.state.one : null}{this.state.isTwo ? this.state.two : null}{this.state.isThree ? this.state.three : null}</div> : null
      }
    </div>;
  }
}